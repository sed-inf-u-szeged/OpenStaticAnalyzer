const Agenda = require('./lib/agenda');

module.exports = Agenda;
