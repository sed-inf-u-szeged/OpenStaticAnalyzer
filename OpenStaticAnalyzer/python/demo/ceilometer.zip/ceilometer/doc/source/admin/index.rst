.. _admin:

=====================
 Administrator Guide
=====================

.. toctree::
   :maxdepth: 2

   telemetry-system-architecture
   telemetry-measurements
   telemetry-troubleshooting-guide
   telemetry-data-pipelines
   telemetry-data-collection
   telemetry-data-retrieval
   telemetry-best-practices
   telemetry-events
