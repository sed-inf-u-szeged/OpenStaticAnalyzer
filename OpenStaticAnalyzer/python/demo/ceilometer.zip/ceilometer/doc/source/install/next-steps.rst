.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the ceilometer service.

To add additional services, see the
`OpenStack Installation Tutorials and Guides <https://docs.openstack.org/#install-guides>`_.
